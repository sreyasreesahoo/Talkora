import authRoutes from "./auth.routes.js";
import userRoutes from "./user.routes.js";
import chatRoutes from "./chat.routes.js";

export { authRoutes, userRoutes, chatRoutes };
